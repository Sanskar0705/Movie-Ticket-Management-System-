<?php
    $host = "localhost";
    $user = "root";      
    $pass = "";            
    $db = "movie";
    $port = 3306;
     $con = mysqli_connect($host, $user, $pass, $db, $port);
?>