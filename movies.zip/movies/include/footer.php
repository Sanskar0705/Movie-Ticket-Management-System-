<div class="footer">
			</div>
			<div class="copy-rights text-center">
				<p>&copy; 2019 Easy Movie Booking. All Rights Reserved | Design by <a href="">Pdwap Tech</a></p>
			</div>
	</div>
</body>
</html>